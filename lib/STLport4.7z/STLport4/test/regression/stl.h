#include<algorithm>
#include<numeric>
#include<new>
#include<deque>
#include<functional>
#include<hash_map>
#include<hash_set>
#include<iterator>
#include<list>
#include<map>
#include<set>
#include<stack>
#include<vector>
#include <slist>
#ifndef __WATCOMC__
#include <rope>
#endif
#ifdef TEST_PTHREAD
#include<pthread_alloc>
#endif
