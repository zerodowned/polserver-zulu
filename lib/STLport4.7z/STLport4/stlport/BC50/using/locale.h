// from <cwchar>
#if !defined (_STLP_NO_MBSTATE_T)
using _STLP_VENDOR_MB_NAMESPACE::mbstate_t;
#endif

// _lib.locale_, locale:
using _STLP_NEW_IO_NAMESPACE::locale;
using _STLP_NEW_IO_NAMESPACE::use_facet;
using _STLP_NEW_IO_NAMESPACE::has_facet;

// _lib.locale.convenience_, convenience interfaces:
using _STLP_NEW_IO_NAMESPACE::isspace;
using _STLP_NEW_IO_NAMESPACE::isprint;
using _STLP_NEW_IO_NAMESPACE::iscntrl;
using _STLP_NEW_IO_NAMESPACE::isupper;
using _STLP_NEW_IO_NAMESPACE::islower;
using _STLP_NEW_IO_NAMESPACE::isalpha;
using _STLP_NEW_IO_NAMESPACE::isdigit;
using _STLP_NEW_IO_NAMESPACE::ispunct;
using _STLP_NEW_IO_NAMESPACE::isxdigit;
using _STLP_NEW_IO_NAMESPACE::isalnum;
using _STLP_NEW_IO_NAMESPACE::isgraph;
using _STLP_NEW_IO_NAMESPACE::toupper;
using _STLP_NEW_IO_NAMESPACE::tolower;

// _lib.category.ctype_ and _lib.facet.ctype.special_, ctype:
using _STLP_NEW_IO_NAMESPACE::ctype_base;
using _STLP_NEW_IO_NAMESPACE::ctype;
using _STLP_NEW_IO_NAMESPACE::ctype_byname;
using _STLP_NEW_IO_NAMESPACE::codecvt_base;
using _STLP_NEW_IO_NAMESPACE::codecvt;
using _STLP_NEW_IO_NAMESPACE::codecvt_byname;

// _lib.category.numeric_ and _lib.facet.numpunct_, numeric:
using _STLP_NEW_IO_NAMESPACE::num_get;
using _STLP_NEW_IO_NAMESPACE::num_put;
using _STLP_NEW_IO_NAMESPACE::numpunct;
using _STLP_NEW_IO_NAMESPACE::numpunct_byname;

// _lib.category.collate_, collation:
using _STLP_NEW_IO_NAMESPACE::collate;
using _STLP_NEW_IO_NAMESPACE::collate_byname;

// _lib.category.time_, date and time:
using _STLP_NEW_IO_NAMESPACE::time_base;
using _STLP_NEW_IO_NAMESPACE::time_get;
using _STLP_NEW_IO_NAMESPACE::time_get_byname;
using _STLP_NEW_IO_NAMESPACE::time_put;
using _STLP_NEW_IO_NAMESPACE::time_put_byname;

// _lib.category.monetary_, money:
using _STLP_NEW_IO_NAMESPACE::money_base;
using _STLP_NEW_IO_NAMESPACE::money_get;
using _STLP_NEW_IO_NAMESPACE::money_put;
using _STLP_NEW_IO_NAMESPACE::moneypunct;
using _STLP_NEW_IO_NAMESPACE::moneypunct_byname;

#if !defined (_STLP_OWN_IOSTREAMS) && !defined (_STLP_NO_NATIVE_MESSAGE_FACET)
using _STLP_NEW_IO_NAMESPACE::messages_base;
using _STLP_NEW_IO_NAMESPACE::messages;
using _STLP_NEW_IO_NAMESPACE::messages_byname;
#endif // _MSL_NO_MESSAGE_FACET
